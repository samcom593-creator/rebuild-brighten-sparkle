import { useRef } from "react";
import { motion } from "framer-motion";
import { Download, Share2, Instagram, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

interface AchievementShareProps {
  agentName: string;
  milestoneType: "hot_streak" | "on_fire" | "unstoppable" | "diamond_week" | "elite_producer" | "first_deal" | "comeback" | "hiring_champion";
  amount?: number;
  date?: string;
}

const MILESTONE_CONFIG: Record<string, { label: string; badge: string; color: string; accent: string; emoji: string }> = {
  hot_streak: { label: "Hot Streak", badge: "5-DAY STREAK", color: "#f97316", accent: "#fed7aa", emoji: "🔥" },
  on_fire: { label: "On Fire", badge: "10-DAY STREAK", color: "#ef4444", accent: "#fecaca", emoji: "🔥🔥" },
  unstoppable: { label: "Unstoppable", badge: "20-DAY STREAK", color: "#7c3aed", accent: "#ddd6fe", emoji: "⚡" },
  diamond_week: { label: "Diamond Week", badge: "$10K+ WEEKLY ALP", color: "#6366f1", accent: "#e0e7ff", emoji: "💎" },
  elite_producer: { label: "Elite Producer", badge: "$25K+ MONTHLY ALP", color: "#0ea5e9", accent: "#bae6fd", emoji: "👑" },
  first_deal: { label: "First Deal!", badge: "FIRST POLICY CLOSED", color: "#10b981", accent: "#d1fae5", emoji: "🎯" },
  comeback: { label: "Comeback King", badge: "BACK STRONGER", color: "#f59e0b", accent: "#fde68a", emoji: "📈" },
  hiring_champion: { label: "Hiring Champion", badge: "TOP RECRUITER", color: "#8b5cf6", accent: "#ede9fe", emoji: "🏆" },
};

export function AchievementShareCard({ agentName, milestoneType, amount, date }: AchievementShareProps) {
  const canvasRef = useRef<HTMLDivElement>(null);
  const config = MILESTONE_CONFIG[milestoneType];
  const firstName = agentName.split(" ")[0];

  const generateAndDownload = async () => {
    // Draw to canvas using html2canvas approach via inline SVG
    const svgContent = generateSVG();
    const blob = new Blob([svgContent], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `apex-${milestoneType}-${firstName.toLowerCase()}.svg`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Graphic downloaded! Share it on Instagram Stories.");
  };

  const copyCaption = () => {
    const captions: Record<string, string> = {
      hot_streak: `🔥 ${agentName} is on a 5-day closing streak at APEX Financial! Consistent effort = consistent results. #APEXFinancial #InsuranceSales #CloseEveryDay`,
      on_fire: `🔥🔥 10 days straight of deals — ${agentName} is literally ON FIRE at APEX Financial! This is what dedication looks like. #APEXFinancial #OnFire #InsuranceAgent`,
      unstoppable: `⚡ 20 CONSECUTIVE DAYS of deals. ${agentName} is UNSTOPPABLE at APEX Financial. Apply to join the team → apex-financial.org/apply #APEXFinancial`,
      diamond_week: `💎 ${agentName} just had a DIAMOND WEEK — $${amount?.toLocaleString()}+ ALP in a single week at APEX Financial! #APEXFinancial #DiamondWeek #Insurance`,
      elite_producer: `👑 ${agentName} is an ELITE PRODUCER at APEX Financial — $${amount?.toLocaleString()}+ ALP this month! Ready to earn like this? apex-financial.org/apply`,
      first_deal: `🎯 ${agentName} just closed their FIRST deal at APEX Financial! Every expert was once a beginner. #APEXFinancial #FirstDeal #InsuranceSales`,
      comeback: `📈 ${agentName} BOUNCED BACK this week at APEX Financial — up massively from last week. Champions don't quit. #APEXFinancial #Comeback`,
      hiring_champion: `🏆 ${agentName} is the HIRING CHAMPION at APEX Financial this week! Building a team = multiplying income. #APEXFinancial #Recruiting`,
    };
    navigator.clipboard.writeText(captions[milestoneType] || "");
    toast.success("Caption copied!");
  };

  const generateSVG = () => `
    <svg width="1080" height="1080" xmlns="http://www.w3.org/2000/svg" font-family="Arial, sans-serif">
      <defs>
        <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:#0a0f1a"/>
          <stop offset="100%" style="stop-color:#1a1f2e"/>
        </linearGradient>
        <linearGradient id="accent" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" style="stop-color:${config.color};stop-opacity:0.8"/>
          <stop offset="100%" style="stop-color:${config.color};stop-opacity:0.3"/>
        </linearGradient>
      </defs>
      
      <!-- Background -->
      <rect width="1080" height="1080" fill="url(#bg)"/>
      
      <!-- Accent bar top -->
      <rect x="0" y="0" width="1080" height="8" fill="${config.color}"/>
      
      <!-- Large emoji/badge area -->
      <circle cx="540" cy="340" r="180" fill="${config.color}" opacity="0.1"/>
      <circle cx="540" cy="340" r="140" fill="${config.color}" opacity="0.15"/>
      <text x="540" y="390" text-anchor="middle" font-size="120">${config.emoji}</text>
      
      <!-- Badge label -->
      <rect x="240" y="540" width="600" height="60" rx="30" fill="${config.color}" opacity="0.2"/>
      <text x="540" y="579" text-anchor="middle" font-size="22" fill="${config.color}" font-weight="bold" letter-spacing="4">
        ${config.badge}
      </text>
      
      <!-- Agent name -->
      <text x="540" y="660" text-anchor="middle" font-size="64" fill="white" font-weight="bold">
        ${firstName}
      </text>
      
      <!-- Milestone label -->
      <text x="540" y="730" text-anchor="middle" font-size="36" fill="${config.color}" font-weight="bold">
        ${config.label.toUpperCase()}
      </text>
      
      <!-- Amount if applicable -->
      ${amount ? `<text x="540" y="790" text-anchor="middle" font-size="28" fill="rgba(255,255,255,0.7)">$${amount.toLocaleString()} ALP</text>` : ""}
      
      <!-- Divider -->
      <rect x="340" y="830" width="400" height="1" fill="rgba(255,255,255,0.2)"/>
      
      <!-- Company -->
      <text x="540" y="880" text-anchor="middle" font-size="24" fill="rgba(255,255,255,0.5)" letter-spacing="6">
        APEX FINANCIAL
      </text>
      
      <!-- CTA -->
      <text x="540" y="940" text-anchor="middle" font-size="18" fill="rgba(255,255,255,0.3)">
        apex-financial.org/apply
      </text>
      
      <!-- Bottom bar -->
      <rect x="0" y="1072" width="1080" height="8" fill="${config.color}"/>
    </svg>
  `;

  return (
    <div className="space-y-4">
      {/* Preview */}
      <div ref={canvasRef} className="relative rounded-xl overflow-hidden aspect-square max-w-xs mx-auto"
        style={{ background: "linear-gradient(135deg, #0a0f1a, #1a1f2e)" }}>
        <div className="absolute top-0 left-0 right-0 h-1.5" style={{ background: config.color }} />
        <div className="flex flex-col items-center justify-center h-full space-y-3 p-6">
          <div className="text-6xl">{config.emoji}</div>
          <div className="px-4 py-1.5 rounded-full text-xs font-bold tracking-widest" style={{ background: `${config.color}25`, color: config.color }}>
            {config.badge}
          </div>
          <div className="text-white font-bold text-2xl">{firstName}</div>
          <div className="font-bold text-lg" style={{ color: config.color }}>{config.label.toUpperCase()}</div>
          {amount && <div className="text-white/60 text-sm">${amount.toLocaleString()} ALP</div>}
          <div className="text-white/30 text-xs tracking-widest">APEX FINANCIAL</div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1.5" style={{ background: config.color }} />
      </div>

      {/* Actions */}
      <div className="flex gap-2">
        <Button onClick={generateAndDownload} className="flex-1 gap-2" size="sm">
          <Download className="h-3.5 w-3.5" /> Download
        </Button>
        <Button onClick={copyCaption} variant="outline" className="flex-1 gap-2" size="sm">
          <Copy className="h-3.5 w-3.5" /> Copy Caption
        </Button>
      </div>
      <p className="text-[10px] text-center text-muted-foreground">1080×1080px — perfect for Instagram Stories & Posts</p>
    </div>
  );
}
