import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { DollarSign, TrendingUp, Target, Calculator, ChevronDown, ChevronUp } from "lucide-react";
import { GlassCard } from "@/components/ui/glass-card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Commission tiers by role
const COMMISSION_RATES: Record<string, { rate: number; label: string }> = {
  agent: { rate: 0.55, label: "Agent (55%)" },
  senior_agent: { rate: 0.65, label: "Senior Agent (65%)" },
  manager: { rate: 0.75, label: "Manager (75%)" },
  senior_manager: { rate: 0.85, label: "Senior Manager (85%)" },
  regional: { rate: 0.95, label: "Regional (95%)" },
};

const MONTHLY_WEEKS = 4.33;

interface CommissionCalculatorProps {
  currentWeekALP?: number;
  role?: string;
}

export function CommissionCalculator({ currentWeekALP = 0, role = "agent" }: CommissionCalculatorProps) {
  const [weeklyALP, setWeeklyALP] = useState(currentWeekALP || 3000);
  const [selectedRole, setSelectedRole] = useState(role);
  const [dealsPerWeek, setDealsPerWeek] = useState(2);
  const [expanded, setExpanded] = useState(false);

  const commRate = COMMISSION_RATES[selectedRole]?.rate || 0.55;

  const weeklyComm = weeklyALP * commRate;
  const monthlyComm = weeklyComm * MONTHLY_WEEKS;
  const yearlyComm = monthlyComm * 12;
  const perDealAvg = dealsPerWeek > 0 ? weeklyALP / dealsPerWeek : 0;
  const perDealComm = perDealAvg * commRate;

  // Override tier targets
  const tierTargets = [
    { label: "Bronze", weeklyALP: 2000, color: "#cd7f32" },
    { label: "Silver", weeklyALP: 5000, color: "#9ca3af" },
    { label: "Gold", weeklyALP: 10000, color: "#eab308" },
    { label: "Diamond", weeklyALP: 20000, color: "#818cf8" },
  ];

  return (
    <GlassCard className="p-5 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Calculator className="h-4 w-4 text-primary" />
          <span className="font-semibold text-sm">Commission Calculator</span>
        </div>
        <button onClick={() => setExpanded(!expanded)} className="text-muted-foreground hover:text-foreground transition-colors">
          {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </button>
      </div>

      {/* Main numbers — always visible */}
      <div className="grid grid-cols-3 gap-3">
        <div className="text-center p-3 rounded-lg bg-primary/5 border border-primary/10">
          <div className="text-xs text-muted-foreground mb-1">This Week</div>
          <div className="text-lg font-bold text-primary">${weeklyComm.toLocaleString(undefined, { maximumFractionDigits: 0 })}</div>
        </div>
        <div className="text-center p-3 rounded-lg bg-card/50 border border-border">
          <div className="text-xs text-muted-foreground mb-1">Monthly</div>
          <div className="text-lg font-bold">${monthlyComm.toLocaleString(undefined, { maximumFractionDigits: 0 })}</div>
        </div>
        <div className="text-center p-3 rounded-lg bg-card/50 border border-border">
          <div className="text-xs text-muted-foreground mb-1">Yearly Pace</div>
          <div className="text-lg font-bold">${(yearlyComm / 1000).toFixed(0)}k</div>
        </div>
      </div>

      {/* ALP slider */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label className="text-xs">Weekly ALP</Label>
          <span className="text-sm font-semibold">${weeklyALP.toLocaleString()}</span>
        </div>
        <Slider
          value={[weeklyALP]}
          onValueChange={([v]) => setWeeklyALP(v)}
          min={0}
          max={30000}
          step={500}
          className="w-full"
        />
        <div className="flex justify-between text-[10px] text-muted-foreground">
          <span>$0</span><span>$10K</span><span>$20K</span><span>$30K</span>
        </div>
      </div>

      {/* Expanded controls */}
      {expanded && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 pt-2 border-t border-border">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs">Commission Level</Label>
              <Select value={selectedRole} onValueChange={setSelectedRole}>
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(COMMISSION_RATES).map(([k, v]) => (
                    <SelectItem key={k} value={k} className="text-xs">{v.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Deals/Week</Label>
              <Input
                type="number"
                value={dealsPerWeek}
                onChange={e => setDealsPerWeek(parseInt(e.target.value) || 1)}
                className="h-8 text-xs"
                min={1} max={20}
              />
            </div>
          </div>

          <div className="p-3 rounded-lg bg-card/50 border border-border space-y-2">
            <div className="text-xs text-muted-foreground font-medium">Per Deal Breakdown</div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Avg ALP per deal</span>
              <span className="font-medium">${perDealAvg.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Commission per deal</span>
              <span className="font-bold text-primary">${perDealComm.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Commission rate</span>
              <span className="font-medium">{(commRate * 100).toFixed(0)}%</span>
            </div>
          </div>

          {/* Tier targets */}
          <div className="space-y-2">
            <div className="text-xs font-medium text-muted-foreground">Income Tiers</div>
            {tierTargets.map(tier => {
              const tierComm = tier.weeklyALP * commRate;
              const isCurrentTier = weeklyALP >= tier.weeklyALP && (tierTargets[tierTargets.indexOf(tier) + 1]?.weeklyALP || 999999) > weeklyALP;
              return (
                <div key={tier.label} className={`flex items-center justify-between p-2 rounded-lg border text-xs ${isCurrentTier ? "bg-primary/5 border-primary/20" : "border-border"}`}>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full" style={{ background: tier.color }} />
                    <span className="font-medium">{tier.label}</span>
                    <span className="text-muted-foreground">${(tier.weeklyALP / 1000).toFixed(0)}K/wk ALP</span>
                  </div>
                  <div className="text-right">
                    <span className="font-bold">${(tierComm * MONTHLY_WEEKS * 12 / 1000).toFixed(0)}K/yr</span>
                    {isCurrentTier && <Badge className="ml-2 text-[9px] px-1 py-0 h-4">You</Badge>}
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>
      )}
    </GlassCard>
  );
}
