import { useState, useEffect, memo, useCallback } from "react";
import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Calendar } from "lucide-react";
import { GlassCard } from "@/components/ui/glass-card";
import { supabase } from "@/integrations/supabase/client";
import { AnimatedNumber } from "./AnimatedNumber";
import { useProductionRealtime } from "@/hooks/useProductionRealtime";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { format, subDays } from "date-fns";

// Memoized tooltip component to prevent ref warnings
const CustomTooltip = memo(({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-background/95 backdrop-blur-sm border border-border rounded-lg p-3 shadow-lg">
        <p className="font-medium text-sm mb-1">{label}</p>
        <p className="text-primary font-bold">
          ${payload[0]?.value?.toLocaleString() || 0}
        </p>
        <p className="text-xs text-muted-foreground">
          {payload[1]?.value || 0} deals
        </p>
      </div>
    );
  }
  return null;
});

CustomTooltip.displayName = "CustomTooltip";

interface ProductionHistoryChartProps {
  agentId?: string;
  weeks?: 4 | 8 | 12;
  showAgencyWide?: boolean; // NEW: Show all agents aggregated
}

interface DayData {
  date: string;
  displayDate: string;
  alp: number;
  deals: number;
  closingRate: number;
}

export function ProductionHistoryChart({ 
  agentId, 
  weeks = 4, 
  showAgencyWide = false 
}: ProductionHistoryChartProps) {
  const [data, setData] = useState<DayData[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedWeeks, setSelectedWeeks] = useState<4 | 8 | 12>(weeks);
  const [summary, setSummary] = useState({
    totalAlp: 0,
    totalDeals: 0,
    avgDaily: 0,
    bestDay: { date: "", amount: 0 },
    trend: 0,
  });

  const fetchHistory = useCallback(async () => {
    try {
      const today = new Date();
      const daysBack = selectedWeeks * 7;
      const startDate = subDays(today, daysBack);
      
      let query = supabase
        .from("daily_production")
        .select("production_date, aop, deals_closed, closing_rate")
        .gte("production_date", startDate.toISOString().split("T")[0])
        .order("production_date", { ascending: true });
      
      // If showing individual agent, filter by agent_id
      if (!showAgencyWide && agentId) {
        query = query.eq("agent_id", agentId);
      }
      
      const { data: production } = await query;

      if (production) {
        // Aggregate by date (for agency-wide, sum all agents per day)
        const dateMap: Record<string, { alp: number; deals: number; closingRates: number[] }> = {};
        
        production.forEach((p) => {
          const dateStr = p.production_date;
          if (!dateMap[dateStr]) {
            dateMap[dateStr] = { alp: 0, deals: 0, closingRates: [] };
          }
          dateMap[dateStr].alp += Number(p.aop || 0);
          dateMap[dateStr].deals += Number(p.deals_closed || 0);
          if (Number(p.closing_rate) > 0) {
            dateMap[dateStr].closingRates.push(Number(p.closing_rate));
          }
        });

        // Fill in missing days with zeros
        const filledData: DayData[] = [];
        for (let i = daysBack - 1; i >= 0; i--) {
          const date = subDays(today, i);
          const dateStr = date.toISOString().split("T")[0];
          const existing = dateMap[dateStr];
          
          const avgClosingRate = existing?.closingRates.length 
            ? existing.closingRates.reduce((a, b) => a + b, 0) / existing.closingRates.length 
            : 0;
          
          filledData.push({
            date: dateStr,
            displayDate: format(date, "MMM d"),
            alp: existing?.alp || 0,
            deals: existing?.deals || 0,
            closingRate: avgClosingRate,
          });
        }

        setData(filledData);

        // Calculate summary
        const withProduction = filledData.filter((d) => d.alp > 0);
        const totalAlp = filledData.reduce((sum, d) => sum + d.alp, 0);
        const totalDeals = filledData.reduce((sum, d) => sum + d.deals, 0);
        const avgDaily = withProduction.length > 0 ? totalAlp / withProduction.length : 0;
        
        // Find best day
        const best = filledData.reduce((max, d) => (d.alp > max.alp ? d : max), filledData[0]);
        
        // Calculate trend (second half vs first half)
        const halfPoint = Math.floor(filledData.length / 2);
        const recentHalf = filledData.slice(halfPoint).reduce((sum, d) => sum + d.alp, 0);
        const olderHalf = filledData.slice(0, halfPoint).reduce((sum, d) => sum + d.alp, 0);
        const trend = olderHalf > 0 ? ((recentHalf - olderHalf) / olderHalf) * 100 : 0;

        setSummary({
          totalAlp,
          totalDeals,
          avgDaily,
          bestDay: { date: best?.displayDate || "", amount: best?.alp || 0 },
          trend,
        });
      }
    } catch (error) {
      console.error("Error fetching history:", error);
    } finally {
      setLoading(false);
    }
  }, [agentId, selectedWeeks, showAgencyWide]);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  // Use shared realtime hook instead of creating separate channel
  useProductionRealtime(fetchHistory, 500);

  if (loading) {
    return (
      <GlassCard className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-muted rounded w-1/3" />
          <div className="h-48 bg-muted/50 rounded" />
        </div>
      </GlassCard>
    );
  }

  const chartTitle = showAgencyWide 
    ? `${selectedWeeks}-Week Agency Production` 
    : `${selectedWeeks}-Week Production History`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
    >
      <GlassCard className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold gradient-text flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            {chartTitle}
          </h3>
          <div className="flex items-center gap-2">
            {/* Time Range Selector */}
            <div className="flex rounded-lg overflow-hidden border border-border">
              {([4, 8, 12] as const).map((w) => (
                <button
                  key={w}
                  onClick={() => setSelectedWeeks(w)}
                  className={`px-2 py-1 text-xs font-medium transition-colors ${
                    selectedWeeks === w
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted hover:bg-muted/80 text-muted-foreground"
                  }`}
                >
                  {w}w
                </button>
              ))}
            </div>
            <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
              summary.trend >= 0 
                ? "bg-emerald-500/20 text-emerald-500" 
                : "bg-red-500/20 text-red-500"
            }`}>
              {summary.trend >= 0 ? (
                <TrendingUp className="h-3 w-3" />
              ) : (
                <TrendingDown className="h-3 w-3" />
              )}
              {Math.abs(summary.trend).toFixed(0)}%
            </div>
          </div>
        </div>

        {/* Chart */}
        <div className="h-48 mb-4">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
              <defs>
                <linearGradient id="alpGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
              <XAxis 
                dataKey="displayDate" 
                tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                tickLine={false}
                axisLine={false}
                interval={6}
              />
              <YAxis 
                tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
                width={40}
              />
              <Tooltip content={<CustomTooltip />} />
              <Area
                type="monotone"
                dataKey="alp"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                fill="url(#alpGradient)"
                isAnimationActive={false}
              />
              <Area
                type="monotone"
                dataKey="deals"
                stroke="hsl(var(--chart-2))"
                strokeWidth={1}
                fill="none"
                strokeDasharray="4 4"
                isAnimationActive={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-4 gap-3">
          <div className="text-center p-3 rounded-lg bg-muted/30">
            <AnimatedNumber
              value={summary.totalAlp}
              formatAsCurrency
              className="text-lg font-bold block"
            />
            <span className="text-[10px] text-muted-foreground">{selectedWeeks}-Week Total</span>
          </div>
          <div className="text-center p-3 rounded-lg bg-muted/30">
            <AnimatedNumber
              value={summary.totalDeals}
              className="text-lg font-bold block"
            />
            <span className="text-[10px] text-muted-foreground">Total Deals</span>
          </div>
          <div className="text-center p-3 rounded-lg bg-muted/30">
            <AnimatedNumber
              value={summary.avgDaily}
              formatAsCurrency
              className="text-lg font-bold block"
            />
            <span className="text-[10px] text-muted-foreground">Avg/Day</span>
          </div>
          <div className="text-center p-3 rounded-lg bg-primary/10 border border-primary/30">
            <AnimatedNumber
              value={summary.bestDay.amount}
              formatAsCurrency
              className="text-lg font-bold block text-primary"
            />
            <span className="text-[10px] text-muted-foreground">Best Day</span>
          </div>
        </div>
      </GlassCard>
    </motion.div>
  );
}
