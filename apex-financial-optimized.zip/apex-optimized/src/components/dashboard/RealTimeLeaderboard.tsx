import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { Trophy, TrendingUp, TrendingDown, Minus, Zap } from "lucide-react";
import { GlassCard } from "@/components/ui/glass-card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { getTodayPST } from "@/lib/dateUtils";

interface LeaderEntry {
  agentId: string;
  name: string;
  avatarInitials: string;
  alp: number;
  deals: number;
  prevRank: number;
  rank: number;
}

const RANK_COLORS = ["text-yellow-500", "text-gray-400", "text-amber-600"];
const RANK_BG = ["bg-yellow-500/10", "bg-gray-400/10", "bg-amber-600/10"];

function AnimatedNumber({ value }: { value: number }) {
  const [display, setDisplay] = useState(value);
  const [flash, setFlash] = useState(false);
  const prevRef = useRef(value);

  useEffect(() => {
    if (value !== prevRef.current) {
      setFlash(true);
      const start = prevRef.current;
      const diff = value - start;
      const steps = 20;
      let step = 0;
      const interval = setInterval(() => {
        step++;
        setDisplay(Math.round(start + (diff * step) / steps));
        if (step >= steps) { clearInterval(interval); setDisplay(value); }
      }, 30);
      prevRef.current = value;
      setTimeout(() => setFlash(false), 800);
      return () => clearInterval(interval);
    }
  }, [value]);

  return (
    <span className={cn("transition-colors duration-300", flash && "text-primary")}>
      ${display.toLocaleString()}
    </span>
  );
}

interface RealTimeLeaderboardProps {
  title?: string;
  period?: "today" | "week" | "month";
  limit?: number;
  currentAgentId?: string;
}

export function RealTimeLeaderboard({ title = "Live Leaderboard", period = "week", limit = 10, currentAgentId }: RealTimeLeaderboardProps) {
  const [entries, setEntries] = useState<LeaderEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [newActivity, setNewActivity] = useState(false);
  const prevEntriesRef = useRef<LeaderEntry[]>([]);

  const today = getTodayPST();
  const weekStart = (() => {
    const d = new Date(today);
    d.setDate(d.getDate() - d.getDay());
    return d.toISOString().split("T")[0];
  })();
  const monthStart = today.slice(0, 7) + "-01";

  const dateFrom = period === "today" ? today : period === "week" ? weekStart : monthStart;

  const fetchLeaderboard = async () => {
    const { data } = await supabase
      .from("daily_production")
      .select("agent_id, aop, deals_closed")
      .gte("production_date", dateFrom);

    if (!data) return;

    // Aggregate by agent
    const totals: Record<string, { alp: number; deals: number }> = {};
    data.forEach((row: any) => {
      if (!totals[row.agent_id]) totals[row.agent_id] = { alp: 0, deals: 0 };
      totals[row.agent_id].alp += Number(row.aop) || 0;
      totals[row.agent_id].deals += Number(row.deals_closed) || 0;
    });

    // Get agent names
    const agentIds = Object.keys(totals);
    if (!agentIds.length) { setLoading(false); return; }

    const { data: agents } = await supabase
      .from("agents")
      .select("id, profile_id, user_id")
      .in("id", agentIds);

    const profileIds = agents?.map((a: any) => a.profile_id || a.user_id).filter(Boolean) || [];
    const { data: profiles } = await supabase
      .from("profiles")
      .select("id, user_id, full_name")
      .or(`id.in.(${profileIds.map((p: string) => `"${p}"`).join(",")}),user_id.in.(${profileIds.map((p: string) => `"${p}"`).join(",")})`);

    const getAgentName = (agentId: string) => {
      const agent = agents?.find((a: any) => a.id === agentId);
      if (!agent) return "Agent";
      const profile = profiles?.find((p: any) => p.id === agent.profile_id || p.user_id === agent.user_id);
      return profile?.full_name || "Agent";
    };

    const sorted = Object.entries(totals)
      .sort(([, a], [, b]) => b.alp - a.alp)
      .slice(0, limit)
      .map(([agentId, stats], idx) => {
        const name = getAgentName(agentId);
        const parts = name.split(" ");
        const initials = (parts[0]?.[0] || "") + (parts[1]?.[0] || "");
        const prev = prevEntriesRef.current.find(e => e.agentId === agentId);
        return {
          agentId,
          name,
          avatarInitials: initials.toUpperCase(),
          alp: stats.alp,
          deals: stats.deals,
          rank: idx + 1,
          prevRank: prev?.rank || idx + 1,
        };
      });

    setEntries(sorted);
    prevEntriesRef.current = sorted;
    setLastUpdate(new Date());
    setLoading(false);
  };

  useEffect(() => {
    fetchLeaderboard();

    // Real-time subscription — fires when any agent logs production
    const channel = supabase
      .channel("leaderboard-realtime")
      .on("postgres_changes", {
        event: "*",
        schema: "public",
        table: "daily_production",
        filter: `production_date=gte.${dateFrom}`,
      }, () => {
        setNewActivity(true);
        setTimeout(() => setNewActivity(false), 3000);
        fetchLeaderboard();
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [period]);

  if (loading) {
    return (
      <GlassCard className="p-5">
        <div className="animate-pulse space-y-3">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-muted" />
              <div className="flex-1 h-4 rounded bg-muted" />
              <div className="w-16 h-4 rounded bg-muted" />
            </div>
          ))}
        </div>
      </GlassCard>
    );
  }

  return (
    <GlassCard className="p-5 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Trophy className="h-4 w-4 text-yellow-500" />
          <span className="font-semibold text-sm">{title}</span>
          <AnimatePresence>
            {newActivity && (
              <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}>
                <Badge className="text-[10px] px-1.5 py-0 h-4 bg-primary/10 text-primary border-primary/20 gap-1">
                  <Zap className="h-2.5 w-2.5" /> Updated
                </Badge>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        {lastUpdate && (
          <span className="text-[10px] text-muted-foreground">
            Live · {lastUpdate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </span>
        )}
      </div>

      <div className="space-y-1">
        <AnimatePresence mode="popLayout">
          {entries.map((entry, idx) => {
            const isMe = entry.agentId === currentAgentId;
            const rankChange = entry.prevRank - entry.rank;
            const isTop3 = entry.rank <= 3;

            return (
              <motion.div
                key={entry.agentId}
                layout
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.3, delay: idx * 0.03 }}
                className={cn(
                  "flex items-center gap-3 p-2.5 rounded-lg transition-colors",
                  isMe ? "bg-primary/5 border border-primary/20" : "hover:bg-muted/30",
                  isTop3 ? RANK_BG[entry.rank - 1] : ""
                )}
              >
                {/* Rank */}
                <div className={cn("w-6 text-center text-sm font-bold flex-shrink-0", isTop3 ? RANK_COLORS[entry.rank - 1] : "text-muted-foreground")}>
                  {entry.rank === 1 ? "🥇" : entry.rank === 2 ? "🥈" : entry.rank === 3 ? "🥉" : entry.rank}
                </div>

                {/* Avatar */}
                <div className={cn("w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold flex-shrink-0",
                  isMe ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground")}>
                  {entry.avatarInitials}
                </div>

                {/* Name */}
                <div className="flex-1 min-w-0">
                  <div className={cn("text-sm font-medium truncate", isMe && "text-primary")}>
                    {entry.name} {isMe && <span className="text-xs font-normal">(you)</span>}
                  </div>
                  <div className="text-[10px] text-muted-foreground">{entry.deals} deal{entry.deals !== 1 ? "s" : ""}</div>
                </div>

                {/* Rank change */}
                {rankChange !== 0 && (
                  <div className={cn("flex items-center gap-0.5 text-[10px] font-medium flex-shrink-0",
                    rankChange > 0 ? "text-green-500" : "text-red-500")}>
                    {rankChange > 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                    {Math.abs(rankChange)}
                  </div>
                )}

                {/* ALP */}
                <div className={cn("text-sm font-bold flex-shrink-0", isTop3 ? RANK_COLORS[entry.rank - 1] : "")}>
                  <AnimatedNumber value={entry.alp} />
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {!entries.length && (
        <div className="text-center py-8 text-sm text-muted-foreground">No production logged yet today.</div>
      )}
    </GlassCard>
  );
}
