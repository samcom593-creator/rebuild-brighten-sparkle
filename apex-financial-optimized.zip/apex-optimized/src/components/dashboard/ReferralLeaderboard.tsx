import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Users, Trophy, Medal, Award, Handshake, Home, Radio } from "lucide-react";
import { GlassCard } from "@/components/ui/glass-card";
import { supabase } from "@/integrations/supabase/client";
import { ConfettiCelebration } from "./ConfettiCelebration";
import { RankChangeIndicator } from "./RankChangeIndicator";
import { useTop3Celebration } from "@/hooks/useTop3Celebration";
import { useRankChange } from "@/hooks/useRankChange";
import { useProductionRealtime } from "@/hooks/useProductionRealtime";
import { cn } from "@/lib/utils";
import { getTodayPST, getWeekStartPST, getMonthStartPST } from "@/lib/dateUtils";

interface ReferralLeaderboardProps {
  currentAgentId?: string;
  period?: "day" | "week" | "month";
}

interface ReferralEntry {
  rank: number;
  agentId: string;
  name: string;
  referralsCaught: number;
  referralPresentations: number;
  bookedInHome: number;
  referralCloseRate: number;
  isCurrentUser: boolean;
}

const rankIcons: Record<number, JSX.Element> = {
  1: <Trophy className="h-4 w-4 text-amber-400" />,
  2: <Medal className="h-4 w-4 text-slate-300" />,
  3: <Award className="h-4 w-4 text-amber-600" />,
};

export function ReferralLeaderboard({ currentAgentId, period = "week" }: ReferralLeaderboardProps) {
  const [entries, setEntries] = useState<ReferralEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [showConfetti, setShowConfetti] = useState(false);
  
  const { checkForCelebration, resetTracking } = useTop3Celebration({ currentAgentId });
  const { getRankChange } = useRankChange("referrals");

  const isInitialMount = useRef(true);

  // Memoize fetchLeaderboard to prevent recreation on each render
  const fetchLeaderboard = useCallback(async (isInitialLoad = true) => {
    try {
      if (isInitialLoad) setLoading(true);
      
      let startDate: string;
      
      // Use PST timezone for all date calculations
      switch (period) {
        case "month":
          startDate = getMonthStartPST();
          break;
        case "day":
          startDate = getTodayPST();
          break;
        default:
          startDate = getWeekStartPST();
      }

      const { data: production } = await supabase
        .from("daily_production")
        .select("agent_id, referrals_caught, referral_presentations, booked_inhome_referrals, deals_closed")
        .gte("production_date", startDate);

      if (!production) {
        setEntries([]);
        setLoading(false);
        return;
      }

      // Aggregate by agent
      const agentTotals: Record<string, { 
        referralsCaught: number; 
        referralPresentations: number;
        bookedInHome: number;
        deals: number;
      }> = {};

      production.forEach((p) => {
        if (!agentTotals[p.agent_id]) {
          agentTotals[p.agent_id] = { 
            referralsCaught: 0, 
            referralPresentations: 0,
            bookedInHome: 0,
            deals: 0,
          };
        }
        agentTotals[p.agent_id].referralsCaught += Number(p.referrals_caught || 0);
        agentTotals[p.agent_id].referralPresentations += Number(p.referral_presentations || 0);
        agentTotals[p.agent_id].bookedInHome += Number(p.booked_inhome_referrals || 0);
        agentTotals[p.agent_id].deals += Number(p.deals_closed || 0);
      });

      // Filter agents with referral activity
      const activeAgents = Object.entries(agentTotals)
        .filter(([_, totals]) => totals.referralsCaught > 0 || totals.referralPresentations > 0);

      if (activeAgents.length === 0) {
        setEntries([]);
        setLoading(false);
        return;
      }

      // Get profiles
      const agentIds = activeAgents.map(([id]) => id);
      const { data: agents } = await supabase
        .from("agents")
        .select("id, user_id, display_name")
        .in("id", agentIds);

      const userIds = agents?.map((a) => a.user_id).filter(Boolean) || [];
      const { data: profiles } = await supabase
        .from("profiles")
        .select("user_id, full_name")
        .in("user_id", userIds);

      // Only include agents we can actually load (handles inactive/deactivated + deleted + RLS visibility)
      const allowedAgentIds = new Set((agents || []).map((a) => a.id));
      const visibleActiveAgents = activeAgents.filter(([id]) => allowedAgentIds.has(id));

      if (visibleActiveAgents.length === 0) {
        setEntries([]);
        setLoading(false);
        return;
      }

      // Build entries
      const referralEntries: ReferralEntry[] = visibleActiveAgents.map(([agentId, totals]) => {
        const agent = agents?.find((a) => a.id === agentId);
        const profile = profiles?.find((p) => p.user_id === agent?.user_id);
        
        // Calculate referral close rate: referral presentations that led to deals
        // This is an approximation since we don't track which deals came from referrals
        const referralCloseRate = totals.referralPresentations > 0 
          ? Math.min((totals.deals / totals.referralPresentations) * 100, 100)
          : 0;

        return {
          rank: 0,
          agentId,
          name: profile?.full_name || agent?.display_name || "Unknown Agent",
          referralsCaught: totals.referralsCaught,
          referralPresentations: totals.referralPresentations,
          bookedInHome: totals.bookedInHome,
          referralCloseRate,
          isCurrentUser: agentId === currentAgentId,
        };
      });

      // Sort by referral presentations (most productive referral activity)
      referralEntries.sort((a, b) => b.referralPresentations - a.referralPresentations);
      referralEntries.forEach((entry, index) => {
        entry.rank = index + 1;
      });

      // Check if current user moved into top 3
      const currentUserEntry = referralEntries.find((e) => e.isCurrentUser);
      if (currentUserEntry && checkForCelebration(currentUserEntry.rank)) {
        setShowConfetti(true);
      }

      setEntries(referralEntries.slice(0, 10));
    } catch (error) {
      console.error("Error fetching referral leaderboard:", error);
    } finally {
      setLoading(false);
    }
  }, [period, currentAgentId, checkForCelebration]);

  useEffect(() => {
    // Only reset tracking on initial mount
    if (isInitialMount.current) {
      resetTracking();
      isInitialMount.current = false;
    }
    fetchLeaderboard(true);
  }, [fetchLeaderboard]);

  // Use shared realtime hook for instant updates
  useProductionRealtime(() => fetchLeaderboard(false), 300);

  return (
    <>
      <ConfettiCelebration 
        trigger={showConfetti} 
        onComplete={() => setShowConfetti(false)} 
      />
      <GlassCard className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Handshake className="h-4 w-4 text-primary" />
            <h4 className="font-semibold text-sm">Top Referral Producers</h4>
          </div>
          <div className="flex items-center gap-1 text-[10px] text-emerald-500">
            <Radio className="h-2.5 w-2.5 animate-pulse" />
            <span>LIVE</span>
          </div>
        </div>

      <div className="space-y-2">
        <AnimatePresence mode="popLayout">
          {loading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="animate-pulse h-10 bg-muted/30 rounded" />
            ))
          ) : entries.length === 0 ? (
            <div className="flex items-center justify-center gap-1.5 py-2 text-xs text-muted-foreground">
              <Handshake className="h-3 w-3" />
              <span>No referral activity yet this period</span>
            </div>
          ) : (
            entries.map((entry, index) => (
              <motion.div
                key={entry.agentId}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className={cn(
                  "flex items-center justify-between p-2 rounded-lg text-sm",
                  entry.isCurrentUser
                    ? "bg-primary/10 border border-primary/30"
                    : "hover:bg-muted/30"
                )}
              >
                <div className="flex items-center gap-2">
                  {rankIcons[entry.rank] || (
                    <span className="w-4 text-center text-xs text-muted-foreground">{entry.rank}</span>
                  )}
                  {(() => {
                    const { change, previousRank } = getRankChange(entry.agentId, entry.rank);
                    return <RankChangeIndicator change={change} previousRank={previousRank} compact />;
                  })()}
                  <span className={cn(
                    "font-medium truncate max-w-[70px]",
                    entry.isCurrentUser && "text-primary"
                  )}>
                    {entry.name.split(" ")[0]}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Users className="h-3 w-3" />
                    <span>{entry.referralsCaught}</span>
                  </div>
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Home className="h-3 w-3" />
                    <span>{entry.bookedInHome}</span>
                  </div>
                  <span className="font-bold text-primary">
                    {entry.referralPresentations} pres
                  </span>
                </div>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>
      </GlassCard>
    </>
  );
}
