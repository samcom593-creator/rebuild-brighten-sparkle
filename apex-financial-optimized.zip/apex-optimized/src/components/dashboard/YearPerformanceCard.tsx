import { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { 
  CalendarDays, 
  TrendingUp, 
  Target, 
  DollarSign,
  BarChart3,
  Award,
  Users
} from "lucide-react";
import { GlassCard } from "@/components/ui/glass-card";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { useProductionRealtime } from "@/hooks/useProductionRealtime";
import { getClosingRateColor } from "@/lib/closingRateColors";

interface YearPerformanceCardProps {
  agentId: string;
  isAdmin?: boolean;
  isManager?: boolean;
}

interface YearStats {
  ytdALP: number;
  ytdDeals: number;
  ytdPresentations: number;
  avgCloseRate: number;
  avgDealSize: number;
}

export function YearPerformanceCard({ agentId, isAdmin = false, isManager = false }: YearPerformanceCardProps) {
  const [stats, setStats] = useState<YearStats | null>(null);
  const [loading, setLoading] = useState(true);
  const currentYear = new Date().getFullYear();

  const fetchYearStats = useCallback(async () => {
    try {
      const yearStart = `${currentYear}-01-01`;
      const yearEnd = `${currentYear}-12-31`;

      // Use server-side RPC for accurate aggregation
      const { data, error } = await supabase.rpc("get_agent_production_stats", {
        start_date: yearStart,
        end_date: yearEnd,
      });

      if (error) throw error;

      let filtered = data || [];

      if (isAdmin) {
        // Admin sees all
        // filtered is already all
      } else if (isManager) {
        // Manager sees their team + self
        // Note: we intentionally do NOT filter by is_deactivated here to keep historical production accurate
        const { data: teamAgents } = await supabase
          .from("agents")
          .select("id")
          .or(`id.eq.${agentId},invited_by_manager_id.eq.${agentId}`);

        const teamIds = new Set(teamAgents?.map(a => a.id) || [agentId]);
        filtered = filtered.filter((r: any) => teamIds.has(r.agent_id));
      } else {
        // Agent sees only personal
        filtered = filtered.filter((r: any) => r.agent_id === agentId);
      }

      if (filtered.length > 0) {
        const ytdALP = filtered.reduce((sum: number, r: any) => sum + Number(r.total_alp || 0), 0);
        const ytdDeals = filtered.reduce((sum: number, r: any) => sum + Number(r.total_deals || 0), 0);
        const ytdPresentations = filtered.reduce((sum: number, r: any) => sum + Number(r.total_presentations || 0), 0);
        
        // Calculate average close rate
        // IMPORTANT: For consistency with other dashboards, we simply sum deals / sum presentations
        // Or if you want "average of rates", you'd sum rates / count.
        // Usually global close rate = total deals / total presentations
        const avgCloseRate = ytdPresentations > 0 ? (ytdDeals / ytdPresentations) * 100 : 0;
        
        const avgDealSize = ytdDeals > 0 ? ytdALP / ytdDeals : 0;

        setStats({ ytdALP, ytdDeals, ytdPresentations, avgCloseRate, avgDealSize });
      } else {
        setStats({ ytdALP: 0, ytdDeals: 0, ytdPresentations: 0, avgCloseRate: 0, avgDealSize: 0 });
      }
    } catch (error) {
      console.error("Error fetching year stats:", error);
    } finally {
      setLoading(false);
    }
  }, [agentId, isAdmin, isManager, currentYear]);

  useEffect(() => {
    if (!agentId) return;
    fetchYearStats();
  }, [agentId, fetchYearStats]);

  // Use shared realtime hook for instant updates
  useProductionRealtime(fetchYearStats, 800);

  if (loading) {
    return (
      <GlassCard className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-muted rounded w-48" />
          <div className="grid grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-24 bg-muted rounded-xl" />
            ))}
          </div>
        </div>
      </GlassCard>
    );
  }

  const closeRateColors = getClosingRateColor(stats?.avgCloseRate || 0);
  
  const statCards = [
    {
      label: "YTD ALP",
      value: `$${Math.round(stats?.ytdALP || 0).toLocaleString()}`,
      icon: DollarSign,
      color: "from-emerald-500/20 to-emerald-500/5 border-emerald-500/20",
      iconColor: "text-emerald-400",
    },
    {
      label: "Total Deals",
      value: stats?.ytdDeals || 0,
      icon: TrendingUp,
      color: "from-amber-500/20 to-amber-500/5 border-amber-500/20",
      iconColor: "text-amber-400",
    },
    {
      label: "Avg Close %",
      value: `${stats?.avgCloseRate.toFixed(1) || 0}%`,
      icon: Target,
      color: closeRateColors.tone === "green" 
        ? "from-green-500/20 to-green-500/5 border-green-500/20" 
        : closeRateColors.tone === "yellow" 
          ? "from-yellow-500/20 to-yellow-500/5 border-yellow-500/20"
          : "from-red-500/20 to-red-500/5 border-red-500/20",
      iconColor: closeRateColors.textClass,
    },
  ];

  return (
    <GlassCard className="p-6 relative overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center h-10 w-10 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 border border-primary/20">
            {isAdmin ? <Users className="h-5 w-5 text-primary" /> : <CalendarDays className="h-5 w-5 text-primary" />}
          </div>
          <div>
            <h3 className="font-bold text-lg">
              {currentYear} {isAdmin ? "Agency" : isManager ? "Team" : ""} Performance
            </h3>
            <p className="text-xs text-muted-foreground">
              {isAdmin ? "All agents YTD" : isManager ? "Team + personal YTD" : "Your YTD stats"}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20">
          <BarChart3 className="h-3.5 w-3.5 text-primary" />
          <span className="text-xs font-medium text-primary">{isAdmin ? "Agency" : "Annual"}</span>
        </div>
      </div>

      {/* Main Stats */}
      <div className="grid grid-cols-3 gap-4 mb-4">
        {statCards.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className={cn(
              "relative overflow-hidden rounded-xl border bg-gradient-to-br p-4 text-center",
              stat.color
            )}
          >
            <div className={cn("mx-auto mb-2 h-8 w-8 rounded-lg bg-background/50 flex items-center justify-center", stat.iconColor)}>
              <stat.icon className="h-4 w-4" />
            </div>
            <p className="text-2xl font-bold text-foreground">{stat.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{stat.label}</p>
            
            {/* Decorative glow */}
            <div className="absolute -right-4 -top-4 h-12 w-12 rounded-full bg-current opacity-10 blur-xl" />
          </motion.div>
        ))}
      </div>

      {/* Bottom Stats */}
      <div className="flex items-center justify-center gap-6 pt-4 border-t border-border/50">
        <div className="flex items-center gap-2 text-sm">
          <Target className="h-4 w-4 text-muted-foreground" />
          <span className="text-muted-foreground">Total Presentations:</span>
          <span className="font-semibold">{stats?.ytdPresentations || 0}</span>
        </div>
        <div className="h-4 w-px bg-border" />
        <div className="flex items-center gap-2 text-sm">
          <Award className="h-4 w-4 text-muted-foreground" />
          <span className="text-muted-foreground">Avg Deal Size:</span>
          <span className="font-semibold">${Math.round(stats?.avgDealSize || 0).toLocaleString()}</span>
        </div>
      </div>

      {/* Background decoration */}
      <div className="absolute -right-8 -bottom-8 h-32 w-32 rounded-full bg-gradient-to-br from-primary/10 to-transparent blur-2xl" />
    </GlassCard>
  );
}
