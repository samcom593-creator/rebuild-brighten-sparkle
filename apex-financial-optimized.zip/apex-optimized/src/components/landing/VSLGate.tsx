import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Lock, Play, CheckCircle2, Clock } from "lucide-react";
import { GlassCard } from "@/components/ui/glass-card";
import { Progress } from "@/components/ui/progress";

interface VSLGateProps {
  videoUrl: string;           // YouTube embed URL or direct MP4
  requiredPercent?: number;   // Default 70
  onUnlocked: () => void;
  children: React.ReactNode;  // The apply form
}

export function VSLGate({ videoUrl, requiredPercent = 70, onUnlocked, children }: VSLGateProps) {
  const [watchPercent, setWatchPercent] = useState(0);
  const [unlocked, setUnlocked] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const watchedRef = useRef<Set<number>>(new Set()); // Track unique seconds watched

  // Check localStorage — if they already watched before, unlock immediately
  useEffect(() => {
    const prev = localStorage.getItem("apex_vsl_unlocked");
    if (prev === "true") { setUnlocked(true); setWatchPercent(100); onUnlocked(); }
  }, []);

  const handleTimeUpdate = () => {
    const v = videoRef.current;
    if (!v || !duration) return;
    const second = Math.floor(v.currentTime);
    watchedRef.current.add(second);
    const watched = watchedRef.current.size;
    const pct = Math.min(100, Math.round((watched / duration) * 100));
    setWatchPercent(pct);
    setCurrentTime(v.currentTime);

    if (pct >= requiredPercent && !unlocked) {
      setUnlocked(true);
      localStorage.setItem("apex_vsl_unlocked", "true");
      onUnlocked();
    }
  };

  const formatTime = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;
  const remaining = Math.max(0, Math.ceil(((requiredPercent / 100) * duration) - watchedRef.current.size));

  return (
    <div className="space-y-6">
      {/* Video */}
      <GlassCard className="p-4 space-y-3">
        <div className="relative rounded-lg overflow-hidden bg-black aspect-video">
          <video
            ref={videoRef}
            src={videoUrl}
            className="w-full h-full object-cover"
            onLoadedMetadata={() => setDuration(Math.floor(videoRef.current?.duration || 0))}
            onTimeUpdate={handleTimeUpdate}
            onPlay={() => setPlaying(true)}
            onPause={() => setPlaying(false)}
            controls
            playsInline
          />
          {!playing && watchPercent === 0 && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/40 pointer-events-none">
              <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm">
                <Play className="h-8 w-8 text-white ml-1" />
              </div>
            </div>
          )}
        </div>

        {/* Progress */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Watch {requiredPercent}% to unlock the application</span>
            <span className={watchPercent >= requiredPercent ? "text-green-500 font-medium" : ""}>
              {watchPercent >= requiredPercent ? "✓ Unlocked!" : `${watchPercent}% watched`}
            </span>
          </div>
          <Progress value={watchPercent} className="h-2" />
          {!unlocked && remaining > 0 && duration > 0 && (
            <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
              <Clock className="h-3 w-3" />
              <span>~{formatTime(remaining)} remaining to unlock</span>
            </div>
          )}
        </div>
      </GlassCard>

      {/* Gated form */}
      <div className="relative">
        <AnimatePresence>
          {!unlocked && (
            <motion.div
              key="gate"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-10 flex flex-col items-center justify-center rounded-xl bg-background/80 backdrop-blur-sm border border-border"
              style={{ minHeight: 200 }}
            >
              <div className="text-center space-y-3 p-6">
                <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mx-auto">
                  <Lock className="h-5 w-5 text-muted-foreground" />
                </div>
                <div>
                  <p className="font-semibold text-sm">Finish watching first</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Watch {requiredPercent}% of the video above to unlock the application.
                    <br />We want serious people on this team.
                  </p>
                </div>
                <div className="text-lg font-bold text-primary">{watchPercent}%</div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className={unlocked ? "" : "opacity-30 pointer-events-none select-none"}>
          {children}
        </div>

        {unlocked && (
          <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mb-4 flex items-center gap-2 text-sm text-green-600 dark:text-green-400 font-medium">
            <CheckCircle2 className="h-4 w-4" />
            Application unlocked — you qualify to apply.
          </motion.div>
        )}
      </div>
    </div>
  );
}
