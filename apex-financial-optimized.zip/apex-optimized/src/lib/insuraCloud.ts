// InsuraCloud API Integration Service
// Add your API key to Supabase secrets as: INSURACLOUD_API_KEY

const BASE_URL = "https://agentlink.insuracloud.ai/api/v1";

// Called from Supabase Edge Functions — never expose API key client-side
export async function insuraCloudFetch(endpoint: string, apiKey: string) {
  const res = await fetch(`${BASE_URL}/${endpoint}`, {
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      "Accept": "application/json",
    },
  });
  if (!res.ok) throw new Error(`InsuraCloud ${endpoint}: ${res.status}`);
  return res.json();
}

// Book of Business — all active policies for an agent
export async function getBookOfBusiness(apiKey: string, agentId?: string) {
  const params = agentId ? `?agent_id=${agentId}` : "";
  return insuraCloudFetch(`book-of-business${params}`, apiKey);
}

// Business Analytics — agency-wide production metrics
export async function getBusinessAnalytics(apiKey: string, from?: string, to?: string) {
  const params = from ? `?from=${from}&to=${to || new Date().toISOString().split("T")[0]}` : "";
  return insuraCloudFetch(`business-analytics${params}`, apiKey);
}

// Team Analytics — manager/team breakdown
export async function getTeamAnalytics(apiKey: string, managerId?: string) {
  const params = managerId ? `?manager_id=${managerId}` : "";
  return insuraCloudFetch(`team-analytics${params}`, apiKey);
}
