import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const resend = new Resend(Deno.env.get("RESEND_API_KEY")!);

  const now = new Date();
  const today = now.toISOString().split("T")[0];
  const sevenDaysAgo = new Date(now); sevenDaysAgo.setDate(now.getDate() - 7);
  const fourteenDaysAgo = new Date(now); fourteenDaysAgo.setDate(now.getDate() - 14);
  const twentyOneDaysAgo = new Date(now); twentyOneDaysAgo.setDate(now.getDate() - 21);

  const { data: agents } = await supabase
    .from("agents")
    .select("id, profile_id, user_id, invited_by_manager_id")
    .eq("is_deactivated", false)
    .eq("status", "active");

  if (!agents?.length) return new Response(JSON.stringify({ checked: 0 }), { headers: corsHeaders });

  const churnRisks: any[] = [];

  for (const agent of agents) {
    let riskScore = 0;
    const flags: string[] = [];

    // Last production date
    const { data: lastProd } = await supabase
      .from("daily_production")
      .select("production_date, aop, deals_closed")
      .eq("agent_id", agent.id)
      .order("production_date", { ascending: false })
      .limit(14);

    const lastDate = lastProd?.[0]?.production_date;
    const daysSinceProduction = lastDate
      ? Math.floor((now.getTime() - new Date(lastDate).getTime()) / 86400000)
      : 999;

    if (daysSinceProduction >= 14) { riskScore += 40; flags.push(`No production in ${daysSinceProduction} days`); }
    else if (daysSinceProduction >= 7) { riskScore += 20; flags.push(`No production in ${daysSinceProduction} days`); }

    // Declining weekly trend
    const thisWeekALP = lastProd?.filter(p => p.production_date >= sevenDaysAgo.toISOString().split("T")[0])
      .reduce((s: number, p: any) => s + (Number(p.aop) || 0), 0) || 0;
    const prevWeekALP = lastProd?.filter(p =>
      p.production_date >= fourteenDaysAgo.toISOString().split("T")[0] &&
      p.production_date < sevenDaysAgo.toISOString().split("T")[0]
    ).reduce((s: number, p: any) => s + (Number(p.aop) || 0), 0) || 0;

    if (prevWeekALP > 0 && thisWeekALP < prevWeekALP * 0.5) {
      riskScore += 20; flags.push(`ALP dropped ${Math.round((1 - thisWeekALP / prevWeekALP) * 100)}% week-over-week`);
    }

    // No course completion
    const { data: courseData } = await supabase
      .from("agent_course_progress")
      .select("completed_at")
      .eq("agent_id", agent.id)
      .maybeSingle();
    if (!courseData?.completed_at) { riskScore += 10; flags.push("Course not completed"); }

    // Attendance score
    const { data: attendance } = await supabase
      .from("agent_attendance")
      .select("status")
      .eq("agent_id", agent.id)
      .gte("date", sevenDaysAgo.toISOString().split("T")[0]);
    const absences = attendance?.filter((a: any) => a.status === "absent").length || 0;
    if (absences >= 3) { riskScore += 15; flags.push(`${absences} absences this week`); }

    if (riskScore < 20) continue;

    // Get profile info
    const { data: profile } = await supabase
      .from("profiles")
      .select("full_name, email")
      .eq("user_id", agent.user_id)
      .maybeSingle();

    const churnLevel = riskScore >= 50 ? "critical" : riskScore >= 30 ? "high" : "medium";

    churnRisks.push({
      agentId: agent.id,
      name: profile?.full_name || "Agent",
      email: profile?.email,
      riskScore,
      churnLevel,
      flags,
      daysSinceProduction,
    });

    // Save to DB
    await supabase.from("churn_risk_alerts").upsert({
      agent_id: agent.id,
      risk_score: riskScore,
      churn_level: churnLevel,
      flags,
      checked_at: now.toISOString(),
      is_resolved: false,
    }, { onConflict: "agent_id" });
  }

  // Send digest to Sam if there are risks
  if (churnRisks.length > 0) {
    const critical = churnRisks.filter(r => r.churnLevel === "critical");
    const high = churnRisks.filter(r => r.churnLevel === "high");

    const agentRows = churnRisks.map(r =>
      `<tr style="border-bottom:1px solid #eee">
        <td style="padding:8px;font-weight:600">${r.name}</td>
        <td style="padding:8px;color:${r.churnLevel === "critical" ? "#dc2626" : r.churnLevel === "high" ? "#ea580c" : "#ca8a04"}">
          ${r.churnLevel.toUpperCase()} (${r.riskScore}/100)
        </td>
        <td style="padding:8px;font-size:12px;color:#666">${r.flags.join(" · ")}</td>
      </tr>`
    ).join("");

    await resend.emails.send({
      from: "APEX System <alerts@apex-financial.org>",
      to: "sam@apex-financial.org",
      subject: `⚠️ Churn Alert: ${critical.length > 0 ? `${critical.length} CRITICAL` : `${high.length} High Risk`} Agent${churnRisks.length > 1 ? "s" : ""}`,
      html: `
        <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
          <h2 style="color:#0a0f1a">Agent Retention Alert</h2>
          <p>${churnRisks.length} agent${churnRisks.length > 1 ? "s" : ""} showing churn signals today.</p>
          <table style="width:100%;border-collapse:collapse">
            <thead><tr style="background:#f5f5f5">
              <th style="padding:8px;text-align:left">Agent</th>
              <th style="padding:8px;text-align:left">Risk Level</th>
              <th style="padding:8px;text-align:left">Signals</th>
            </tr></thead>
            <tbody>${agentRows}</tbody>
          </table>
          <p style="margin-top:16px"><a href="https://apex-financial.org/dashboard/crm" style="background:#0a0f1a;color:white;padding:10px 20px;border-radius:6px;text-decoration:none">View in Dashboard</a></p>
        </div>
      `,
    });
  }

  return new Response(JSON.stringify({ checked: agents.length, flagged: churnRisks.length, risks: churnRisks }), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
