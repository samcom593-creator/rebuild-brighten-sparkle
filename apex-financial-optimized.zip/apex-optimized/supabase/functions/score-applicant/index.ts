import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  const { applicationId } = await req.json();

  const { data: app } = await supabase
    .from("applications")
    .select("*")
    .eq("id", applicationId)
    .maybeSingle();

  if (!app) return new Response(JSON.stringify({ score: 0 }), { headers: corsHeaders });

  let score = 50; // Base score
  const signals: string[] = [];

  // Licensed = immediate +25
  if (app.license_status === "licensed") { score += 25; signals.push("Licensed agent (+25)"); }
  else if (app.license_status === "pending") { score += 10; signals.push("License pending (+10)"); }

  // Prior insurance experience
  if (app.has_insurance_experience) {
    score += 10; signals.push("Has insurance exp (+10)");
    if (app.years_experience >= 3) { score += 5; signals.push("3+ years exp (+5)"); }
  }

  // Has downlines = serious recruiter
  if (app.number_of_downlines > 0) {
    const bonus = Math.min(app.number_of_downlines * 3, 15);
    score += bonus; signals.push(`Has downlines (+${bonus})`);
  }

  // Motivation length signals serious intent
  const motivLen = (app.motivation || "").length;
  if (motivLen > 200) { score += 8; signals.push("Detailed motivation (+8)"); }
  else if (motivLen > 100) { score += 4; signals.push("Good motivation (+4)"); }
  else if (motivLen < 30) { score -= 10; signals.push("Weak motivation (-10)"); }

  // Availability
  if (app.availability === "full_time") { score += 8; signals.push("Full time (+8)"); }
  else if (app.availability === "part_time_20_plus") { score += 4; signals.push("Part time 20h+ (+4)"); }

  // Has Instagram = social seller
  if (app.instagram_handle) { score += 5; signals.push("Has Instagram (+5)"); }

  // Referred = warmer lead
  if (app.referred_by_agent_id) { score += 8; signals.push("Referred (+8)"); }

  // NIPR number = licensed and ready
  if (app.nipr_number) { score += 7; signals.push("NIPR on file (+7)"); }

  // Multiple states licensed
  if (app.licensed_states && app.licensed_states.length > 1) {
    score += 5; signals.push("Multi-state (+5)");
  }

  // Cap at 100
  score = Math.min(100, Math.max(0, score));

  const tier =
    score >= 80 ? "hot" :
    score >= 60 ? "warm" :
    score >= 40 ? "cool" : "cold";

  // Save score to application
  await supabase
    .from("applications")
    .update({ ai_score: score, ai_score_tier: tier, ai_score_signals: signals, ai_scored_at: new Date().toISOString() })
    .eq("id", applicationId);

  return new Response(JSON.stringify({ score, tier, signals }), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
