import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SEQUENCES: Record<number, { subject: string; headline: string; body: string; cta: string }> = {
  1: {
    subject: "Your first step to getting licensed 🎯",
    headline: "Welcome to the team. Let's get you licensed.",
    body: `The fastest agents on our team go from contracted to licensed in under 3 weeks. Here's what you do first: purchase the pre-licensing course and start studying. That's it. One action today.`,
    cta: "Get the Pre-Licensing Course →",
  },
  3: {
    subject: "Quick check-in on your license progress",
    headline: "Day 3 — where are you at?",
    body: `Most agents who wait more than a week to start the course end up waiting months. The ones who start immediately are in the field earning within 30 days. Today, open the course and complete the first module. That's 30 minutes that changes everything.`,
    cta: "Submit Your Progress →",
  },
  7: {
    subject: "One week in — time to schedule your test",
    headline: "If you've been studying, it's time to book the exam.",
    body: `This is the moment most unlicensed agents get stuck. Don't let scheduling friction stop you. Book the exam today even if you don't feel 100% ready. Having a date on the calendar changes how you study. Check-in below with your progress.`,
    cta: "Check In Now →",
  },
  14: {
    subject: "Still with us? Let's talk.",
    headline: "Two weeks since you contracted.",
    body: `I noticed you haven't completed the licensing process yet. That's okay — life gets in the way. But I want to make sure you don't lose momentum. If there's something blocking you, reply to this email and tell me what it is. I'll personally help you get unstuck.`,
    cta: "Tell Sam What's Blocking You →",
  },
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const resend = new Resend(Deno.env.get("RESEND_API_KEY")!);

  const now = new Date();
  const today = now.toISOString().split("T")[0];
  let sent = 0;

  // Get all unlicensed contracted applicants
  const { data: applicants } = await supabase
    .from("applications")
    .select("id, first_name, last_name, email, phone, contracted_at, license_progress, license_status")
    .eq("license_status", "unlicensed")
    .not("contracted_at", "is", null)
    .is("terminated_at", null);

  if (!applicants?.length) return new Response(JSON.stringify({ sent: 0 }), { headers: corsHeaders });

  for (const app of applicants) {
    // Skip already licensed
    if (app.license_progress === "exam_passed" || app.license_progress === "fingerprints_done" || app.license_progress === "pending_state") continue;

    const contractedDate = new Date(app.contracted_at);
    const daysSinceContracted = Math.floor((now.getTime() - contractedDate.getTime()) / 86400000);

    const sequenceDay = [1, 3, 7, 14].find(d => d === daysSinceContracted);
    if (!sequenceDay) continue;

    const seq = SEQUENCES[sequenceDay];
    if (!seq) continue;

    // Check if already sent this sequence
    const { data: existing } = await supabase
      .from("notification_log")
      .select("id")
      .eq("recipient_email", app.email)
      .eq("notification_type", `licensing_sequence_day_${sequenceDay}`)
      .maybeSingle();

    if (existing) continue;

    try {
      const checkinUrl = `https://apex-financial.org/daily-checkin`;
      const contactUrl = `mailto:sam@apex-financial.org?subject=Licensing Help - ${app.first_name} ${app.last_name}`;

      await resend.emails.send({
        from: "Sam · APEX <sam@apex-financial.org>",
        to: app.email,
        subject: seq.subject,
        html: `
          <div style="font-family:sans-serif;max-width:560px;margin:0 auto;color:#0a0f1a">
            <div style="background:#0a0f1a;padding:24px;border-radius:12px 12px 0 0">
              <h1 style="color:white;margin:0;font-size:20px">APEX Financial</h1>
              <p style="color:rgba(255,255,255,0.5);margin:4px 0 0;font-size:13px">Licensing Journey · Day ${sequenceDay}</p>
            </div>
            <div style="background:#f9f9f9;padding:24px;border-radius:0 0 12px 12px">
              <h2 style="margin:0 0 16px">${app.first_name}, ${seq.headline}</h2>
              <p style="line-height:1.7;margin:0 0 24px">${seq.body}</p>
              <a href="${sequenceDay === 14 ? contactUrl : checkinUrl}" style="display:block;text-align:center;background:#0a0f1a;color:white;padding:14px;border-radius:8px;text-decoration:none;font-weight:600;font-size:15px">
                ${seq.cta}
              </a>
              <p style="margin:20px 0 0;font-size:13px;color:#666">— Sam, Managing Partner<br>APEX Financial</p>
            </div>
          </div>
        `,
      });

      // Also send SMS
      await fetch(`${Deno.env.get("SUPABASE_URL")}/functions/v1/send-sms-auto-detect`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")}` },
        body: JSON.stringify({
          phone: app.phone,
          message: `APEX: ${app.first_name}, ${sequenceDay === 1 ? "welcome! Your first step is starting the pre-licensing course." : sequenceDay === 3 ? "Day 3 check-in — have you started the course?" : sequenceDay === 7 ? "Time to schedule your licensing exam! Book it today." : "Still need help getting licensed? Reply and Sam will reach out personally."} Check in: ${checkinUrl}`,
          carrier: "auto",
        }),
      });

      // Log it
      await supabase.from("notification_log").insert({
        recipient_email: app.email,
        notification_type: `licensing_sequence_day_${sequenceDay}`,
        sent_at: now.toISOString(),
        application_id: app.id,
      });

      sent++;
    } catch (e) {
      console.error(`Sequence failed for ${app.email}:`, e);
    }
  }

  return new Response(JSON.stringify({ sent, checked: applicants.length }), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
