import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const resend = new Resend(Deno.env.get("RESEND_API_KEY")!);

  const now = new Date();
  const sevenDaysAgo = new Date(now); sevenDaysAgo.setDate(now.getDate() - 7);
  const fourteenDaysAgo = new Date(now); fourteenDaysAgo.setDate(now.getDate() - 14);

  const { data: agents } = await supabase
    .from("agents")
    .select("id, user_id")
    .eq("is_deactivated", false)
    .eq("status", "active");

  if (!agents?.length) return new Response(JSON.stringify({ sent: 0 }), { headers: corsHeaders });

  let sent = 0;

  for (const agent of agents) {
    try {
      const { data: profile } = await supabase
        .from("profiles")
        .select("full_name, email")
        .eq("user_id", agent.user_id)
        .maybeSingle();

      if (!profile?.email) continue;

      const firstName = profile.full_name?.split(" ")[0] || "Agent";

      // Last week's production
      const { data: lastWeek } = await supabase
        .from("daily_production")
        .select("aop, deals_closed, presentations, hours_called")
        .eq("agent_id", agent.id)
        .gte("production_date", sevenDaysAgo.toISOString().split("T")[0]);

      const { data: prevWeek } = await supabase
        .from("daily_production")
        .select("aop, deals_closed, presentations")
        .eq("agent_id", agent.id)
        .gte("production_date", fourteenDaysAgo.toISOString().split("T")[0])
        .lt("production_date", sevenDaysAgo.toISOString().split("T")[0]);

      const lastALP = lastWeek?.reduce((s: number, r: any) => s + (Number(r.aop) || 0), 0) || 0;
      const lastDeals = lastWeek?.reduce((s: number, r: any) => s + (Number(r.deals_closed) || 0), 0) || 0;
      const lastPresentations = lastWeek?.reduce((s: number, r: any) => s + (Number(r.presentations) || 0), 0) || 0;
      const prevALP = prevWeek?.reduce((s: number, r: any) => s + (Number(r.aop) || 0), 0) || 0;
      const closeRate = lastPresentations > 0 ? Math.round((lastDeals / lastPresentations) * 100) : 0;

      // AI-style personalized coaching based on actual stats
      const targetALP = Math.max(lastALP * 1.2, 5000);
      const targetDeals = Math.max(lastDeals + 1, 3);
      const targetPresentations = Math.ceil(targetDeals / Math.max(closeRate / 100, 0.25));

      let coachingLine = "";
      let focusArea = "";

      if (lastALP === 0) {
        coachingLine = `Let's get your first deal this week. Focus on presentations — even 5 presentations at average close rate gets you a deal.`;
        focusArea = "First Deal";
      } else if (closeRate < 25) {
        coachingLine = `Your volume is good but your close rate is at ${closeRate}%. This week focus on the presentation quality, not quantity. Slow down at the price point — that's where deals are lost.`;
        focusArea = "Close Rate";
      } else if (lastALP < prevALP * 0.8) {
        coachingLine = `You dropped from last week. Don't let two slow days become a slow week. Call your oldest leads first — they've already been sold once.`;
        focusArea = "Bounce Back";
      } else if (lastALP >= 8000) {
        coachingLine = `You're producing at a high level. This week push for ${targetDeals} deals and see if you can break your personal record.`;
        focusArea = "Break Records";
      } else {
        coachingLine = `Solid week. Now build on it. Your target this week is $${targetALP.toLocaleString()} ALP — that's just ${Math.ceil((targetALP - lastALP) / Math.max(lastDeals, 1)).toLocaleString()} more per deal than last week.`;
        focusArea = "Growth";
      }

      await resend.emails.send({
        from: "Sam · APEX <sam@apex-financial.org>",
        to: profile.email,
        subject: `${firstName}, your week starts now — ${focusArea} focus`,
        html: `
          <div style="font-family:sans-serif;max-width:560px;margin:0 auto;color:#0a0f1a">
            <div style="background:#0a0f1a;padding:24px;border-radius:12px 12px 0 0">
              <h1 style="color:white;margin:0;font-size:20px">APEX Financial</h1>
              <p style="color:rgba(255,255,255,0.6);margin:4px 0 0;font-size:13px">Weekly Coaching · ${now.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}</p>
            </div>
            <div style="background:#f9f9f9;padding:24px;border-radius:0 0 12px 12px">
              <h2 style="margin:0 0 16px;font-size:18px">Good morning, ${firstName}.</h2>

              <div style="background:white;border-radius:8px;padding:16px;margin-bottom:16px;border:1px solid #eee">
                <p style="margin:0 0 12px;font-size:13px;color:#666;text-transform:uppercase;letter-spacing:.5px">Last Week</p>
                <div style="display:flex;gap:16px">
                  <div><div style="font-size:24px;font-weight:700">$${lastALP.toLocaleString()}</div><div style="font-size:12px;color:#666">ALP</div></div>
                  <div><div style="font-size:24px;font-weight:700">${lastDeals}</div><div style="font-size:12px;color:#666">Deals</div></div>
                  <div><div style="font-size:24px;font-weight:700">${closeRate}%</div><div style="font-size:12px;color:#666">Close Rate</div></div>
                </div>
              </div>

              <div style="background:#0a0f1a;border-radius:8px;padding:16px;margin-bottom:16px;color:white">
                <p style="margin:0 0 8px;font-size:12px;color:rgba(255,255,255,0.6);text-transform:uppercase">This Week's Focus: ${focusArea}</p>
                <p style="margin:0;line-height:1.6">${coachingLine}</p>
              </div>

              <div style="background:white;border-radius:8px;padding:16px;border:1px solid #eee;margin-bottom:16px">
                <p style="margin:0 0 12px;font-size:13px;color:#666;text-transform:uppercase;letter-spacing:.5px">This Week's Targets</p>
                <div style="display:flex;gap:16px">
                  <div><div style="font-size:20px;font-weight:700;color:#059669">$${Math.round(targetALP).toLocaleString()}</div><div style="font-size:12px;color:#666">ALP Target</div></div>
                  <div><div style="font-size:20px;font-weight:700;color:#059669">${targetDeals}</div><div style="font-size:12px;color:#666">Deal Target</div></div>
                  <div><div style="font-size:20px;font-weight:700;color:#059669">${targetPresentations}</div><div style="font-size:12px;color:#666">Presentations Needed</div></div>
                </div>
              </div>

              <a href="https://apex-financial.org/agent-portal" style="display:block;text-align:center;background:#0a0f1a;color:white;padding:12px;border-radius:8px;text-decoration:none;font-weight:600">
                Log Today's Numbers →
              </a>
            </div>
          </div>
        `,
      });

      sent++;
    } catch (e) {
      console.error(`Failed for agent ${agent.id}:`, e);
    }
  }

  return new Response(JSON.stringify({ sent }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
});
