import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const INSURACLOUD_BASE = "https://agentlink.insuracloud.ai/api/v1";

async function insuraFetch(endpoint: string, apiKey: string) {
  const res = await fetch(`${INSURACLOUD_BASE}/${endpoint}`, {
    headers: { "Authorization": `Bearer ${apiKey}`, "Accept": "application/json" },
  });
  if (!res.ok) {
    console.error(`InsuraCloud ${endpoint} failed: ${res.status}`);
    return null;
  }
  return res.json();
}

serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const apiKey = Deno.env.get("INSURACLOUD_API_KEY");

  if (!apiKey) {
    return new Response(JSON.stringify({ error: "INSURACLOUD_API_KEY not set in Supabase secrets" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const now = new Date().toISOString();
  const results: Record<string, any> = {};

  // 1. Book of Business
  const bob = await insuraFetch("book-of-business", apiKey);
  if (bob) {
    results.bookOfBusiness = bob;
    await supabase.from("insuracloud_cache").upsert({
      cache_key: "book-of-business",
      data: bob,
      synced_at: now,
    }, { onConflict: "cache_key" });
  }

  // 2. Business Analytics
  const analytics = await insuraFetch("business-analytics", apiKey);
  if (analytics) {
    results.businessAnalytics = analytics;
    await supabase.from("insuracloud_cache").upsert({
      cache_key: "business-analytics",
      data: analytics,
      synced_at: now,
    }, { onConflict: "cache_key" });
  }

  // 3. Team Analytics
  const team = await insuraFetch("team-analytics", apiKey);
  if (team) {
    results.teamAnalytics = team;
    await supabase.from("insuracloud_cache").upsert({
      cache_key: "team-analytics",
      data: team,
      synced_at: now,
    }, { onConflict: "cache_key" });
  }

  console.log(`InsuraCloud sync complete: ${Object.keys(results).join(", ")}`);

  return new Response(JSON.stringify({ success: true, synced: Object.keys(results), at: now }), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
