-- Field agent check-ins table
CREATE TABLE IF NOT EXISTS field_checkins (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
  checkin_date DATE NOT NULL,
  checkin_time TIMESTAMPTZ NOT NULL DEFAULT now(),
  client_name TEXT,
  client_phone TEXT,
  product_discussed TEXT,
  outcome TEXT NOT NULL CHECK (outcome IN ('presented', 'no_decision', 'closed', 'reschedule', 'not_home')),
  notes TEXT,
  reschedule_date TIMESTAMPTZ,
  alp NUMERIC(10,2) DEFAULT 0,
  lat DOUBLE PRECISION,
  lng DOUBLE PRECISION,
  location_accuracy DOUBLE PRECISION,
  is_offline_sync BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_field_checkins_agent_date ON field_checkins(agent_id, checkin_date);
CREATE INDEX IF NOT EXISTS idx_field_checkins_date ON field_checkins(checkin_date);

-- RLS
ALTER TABLE field_checkins ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Agents can insert own checkins" ON field_checkins FOR INSERT WITH CHECK (
  agent_id IN (SELECT id FROM agents WHERE user_id = auth.uid())
);
CREATE POLICY "Agents can view own checkins" ON field_checkins FOR SELECT USING (
  agent_id IN (SELECT id FROM agents WHERE user_id = auth.uid())
);
CREATE POLICY "Admins can view all checkins" ON field_checkins FOR SELECT USING (
  EXISTS (SELECT 1 FROM profiles WHERE user_id = auth.uid() AND role IN ('admin', 'manager'))
);

-- Churn risk alerts
CREATE TABLE IF NOT EXISTS churn_risk_alerts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE UNIQUE,
  risk_score INTEGER NOT NULL DEFAULT 0,
  churn_level TEXT NOT NULL CHECK (churn_level IN ('medium', 'high', 'critical')),
  flags TEXT[] DEFAULT '{}',
  checked_at TIMESTAMPTZ DEFAULT now(),
  is_resolved BOOLEAN DEFAULT false,
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_churn_risk_agent ON churn_risk_alerts(agent_id);
CREATE INDEX IF NOT EXISTS idx_churn_risk_level ON churn_risk_alerts(churn_level);

ALTER TABLE churn_risk_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can manage churn alerts" ON churn_risk_alerts FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE user_id = auth.uid() AND role IN ('admin', 'manager'))
);

-- AI scoring columns on applications
ALTER TABLE applications ADD COLUMN IF NOT EXISTS ai_score INTEGER;
ALTER TABLE applications ADD COLUMN IF NOT EXISTS ai_score_tier TEXT;
ALTER TABLE applications ADD COLUMN IF NOT EXISTS ai_score_signals TEXT[];
ALTER TABLE applications ADD COLUMN IF NOT EXISTS ai_scored_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_applications_ai_score ON applications(ai_score DESC);
CREATE INDEX IF NOT EXISTS idx_applications_ai_tier ON applications(ai_score_tier);

-- Notification log additions
ALTER TABLE notification_log ADD COLUMN IF NOT EXISTS application_id UUID REFERENCES applications(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_notif_log_app ON notification_log(application_id);
