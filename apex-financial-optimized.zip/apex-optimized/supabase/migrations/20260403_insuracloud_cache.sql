-- InsuraCloud data cache table
-- Stores API responses so dashboard loads instantly (no API call on page load)
CREATE TABLE IF NOT EXISTS insuracloud_cache (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  cache_key TEXT NOT NULL UNIQUE,
  data JSONB NOT NULL,
  synced_at TIMESTAMPTZ DEFAULT now(),
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_insuracloud_cache_key ON insuracloud_cache(cache_key);

-- Allow admins/managers to read InsuraCloud cache
ALTER TABLE insuracloud_cache ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins read insuracloud cache" ON insuracloud_cache FOR SELECT USING (
  EXISTS (SELECT 1 FROM profiles WHERE user_id = auth.uid() AND role IN ('admin', 'manager'))
);
CREATE POLICY "Service role manages insuracloud cache" ON insuracloud_cache FOR ALL USING (true);

-- Add InsuraCloud sync to cron (runs every 30 minutes)
-- Run this in SQL Editor after enabling pg_cron extension:
-- SELECT cron.schedule('sync-insuracloud', '*/30 * * * *', $$
--   SELECT net.http_post(
--     'https://msydzhzolwourcdmqxvn.supabase.co/functions/v1/sync-insuracloud',
--     '{}', 'application/json',
--     ARRAY[http_header('Authorization', 'Bearer YOUR_SERVICE_ROLE_KEY')]
--   );
-- $$);

-- NOTE: Add INSURACLOUD_API_KEY to Supabase secrets:
-- Dashboard → Settings → Edge Functions → Add secret → INSURACLOUD_API_KEY = your_key
